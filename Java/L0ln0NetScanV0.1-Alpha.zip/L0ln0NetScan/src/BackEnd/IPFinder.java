package BackEnd;

import java.net.InetAddress;

import FrontEnd.Ventana;

public class IPFinder implements Runnable{
	private int cont_d, cont_n, contini, contfin, milsec;
	private String dip;
	InetAddress ip;
	Data data;
	Ventana v;
	
	public IPFinder(String direc, int inicio, int fin, int secs, Data dat, Ventana ven) {
		this.cont_d = 0;
		this.cont_n = 0;
		this.contini = inicio;
		this.contfin = fin;
		this.milsec = secs;
		this.dip = direc;
		data = dat;
		v=ven;
	}
	
	public void run() {
		searchIPs(getDip());
		v.setAreaTextoIP("Disponibles: "+getCont_d()+" No Disponibles: "+getCont_n());
		v.getBuscar().setEnabled(true);
	}
	
	public String getDip() {
		return dip;
	}

	public void setDip(String dip) {
		this.dip = dip;
	}

	public int getCont_d() {
		return cont_d;
	}


	public void setCont_d(int cont_d) {
		this.cont_d = cont_d;
	}


	public int getCont_n() {
		return cont_n;
	}


	public void setCont_n(int cont_n) {
		this.cont_n = cont_n;
	}


	public int getContini() {
		return contini;
	}

	public void setContini(int contini) {
		this.contini = contini;
	}

	public int getContfin() {
		return contfin;
	}

	public void setContfin(int contfin) {
		this.contfin = contfin;
	}

	public int getMilsec() {
		return milsec;
	}

	public void setMilsec(int milsec) {
		this.milsec = milsec;
	}
	public void searchIPs(String sIP) {
		try {
			for(int i=this.getContini();i<this.getContfin();i++) {
				ip = InetAddress.getByName(sIP+i);
				if(ip.isReachable(100)) {
					if(data.addAviableIP(ip.getHostAddress())) {
						this.setCont_d(getCont_d()+1);
					} else {
						break;
					}
				} else {
					if(data.addNoAviableIPs(ip.getHostAddress())) {
						this.setCont_n(getCont_n()+1);	
					} else {
						break;
					}
				}
			}
		} catch(Exception e) {}
	}
}
