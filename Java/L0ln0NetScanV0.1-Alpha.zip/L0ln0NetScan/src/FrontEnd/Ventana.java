package FrontEnd;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

import BackEnd.*;

public class Ventana extends JFrame implements ActionListener{
	private static final long serialVersionUID = 7059548718373831736L;
	private JLabel lblIP, lblIni, lblFin, lblMili, mensajes;
	private JTextPane areaTextoIP, areaTextoPorts, areaTextoInfo;
	private JButton buscar, detener;
	private JTextField campoIP, rangoIni, rangoFin, mSecs;
	private JScrollPane scrollIP, scrollPorts, scrollInfo;
	private JPanel panelSup;
	private String baseInfo;
	Data data;
	IPFinder finder;
	
	public Ventana() {
		super("L0ln0NetScan V0.1");
		data = new Data();
		baseInfo="<<< IP's\t               Ports>>>\n";
		this.setBounds(0, 0, 900, 600);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		panelSup = new JPanel(new FlowLayout());
		lblIP = new JLabel("Rango IP: ");
		lblIni = new JLabel("Rango Ini.: ");
		lblFin = new JLabel("Rango Fin: ");
		lblMili = new JLabel("Delay(ms): ");
		campoIP = new JTextField(20);
		rangoIni = new JTextField(3);
		rangoFin = new JTextField(3);
		mSecs = new JTextField(10);
		buscar = new JButton("Buscar");
		detener = new JButton("Detener");
		panelSup.add(lblIP);
		panelSup.add(campoIP);
		panelSup.add(lblIni);
		panelSup.add(rangoIni);
		panelSup.add(lblFin);
		panelSup.add(rangoFin);
		panelSup.add(lblMili);
		panelSup.add(mSecs);
		panelSup.add(buscar);
		panelSup.add(detener);
		this.add(panelSup,BorderLayout.NORTH);
		areaTextoIP = new JTextPane();
		areaTextoIP.setPreferredSize(new Dimension(350,60));
		areaTextoIP.setEditable(false);
		areaTextoPorts = new JTextPane();
		areaTextoPorts.setPreferredSize(new Dimension(350,60));
		areaTextoPorts.setEditable(false);
		areaTextoInfo = new JTextPane();
		areaTextoInfo.setEditable(false);
		areaTextoInfo.setPreferredSize(new Dimension(50,50));
		scrollInfo = new JScrollPane(areaTextoInfo);
		scrollIP = new JScrollPane(areaTextoIP);
		scrollPorts = new JScrollPane(areaTextoPorts);
		this.add(scrollIP, BorderLayout.WEST);
		this.add(scrollPorts, BorderLayout.EAST);
		this.add(scrollInfo,BorderLayout.CENTER);
		mensajes = new JLabel("Listo.");
		this.add(mensajes, BorderLayout.SOUTH);
		buscar.addActionListener(this);
		detener.addActionListener(this);
		setAreaTextoInfo("<<< IP's\t               Ports>>>\n");
		this.setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==buscar) {
			getBuscar().setEnabled(false);
			int fln = Integer.parseInt(getRangoFin().getText());
			int ini=Integer.parseInt(getRangoIni().getText());
			int mscs = Integer.parseInt(getmSecs().getText());
			finder = new IPFinder(getCampoIP().getText(),ini,fln,mscs,data,this);
			//finder.run();
			setAreaTextoInfo(baseInfo+"\n Cargando informaci�n, por favor espere");
			finder.searchIPs(getCampoIP().getText());
			setAreaTextoIP("Disponibles: "+finder.getCont_d()+" No Disponibles: "+finder.getCont_n());
			setAreaTextoInfo(baseInfo);
			getBuscar().setEnabled(true);
		}
		if(e.getSource()==detener) {
			
		}
	}
	
	public String getBaseInfo() {
		return baseInfo;
	}

	public JTextPane getAreaTextoIP() {
		return areaTextoIP;
	}

	public JTextPane getAreaTextoPorts() {
		return areaTextoPorts;
	}

	public JButton getBuscar() {
		return buscar;
	}

	public JButton getDetener() {
		return detener;
	}

	public JTextField getCampoIP() {
		return campoIP;
	}

	public void setAreaTextoIP(String areaTextoIP) {
		this.areaTextoIP.setText(areaTextoIP);
	}

	public void setAreaTextoPorts(String areaTextoPorts) {
		this.areaTextoPorts.setText(areaTextoPorts);
	}

	public void setBuscar(JButton buscar) {
		this.buscar = buscar;
	}

	public void setDetener(JButton detener) {
		this.detener = detener;
	}

	public void setCampoIP(String campoIP) {
		this.campoIP.setText(campoIP);
	}

	public JTextPane getAreaTextoInfo() {
		return areaTextoInfo;
	}

	public void setAreaTextoInfo(String areaTextoInfo) {
		this.areaTextoInfo.setText(areaTextoInfo);
	}

	public JLabel getLblIP() {
		return lblIP;
	}

	public void setLblIP(String lblIP) {
		this.lblIP.setText(lblIP);
	}

	public JLabel getLblIni() {
		return lblIni;
	}

	public void setLblIni(String lblIni) {
		this.lblIni.setText(lblIni);
	}

	public JLabel getLblFin() {
		return lblFin;
	}

	public void setLblFin(String lblFin) {
		this.lblFin.setText(lblFin);
	}

	public JLabel getLblMili() {
		return lblMili;
	}

	public void setLblMili(String lblMili) {
		this.lblMili.setText(lblMili);
	}

	public JLabel getMensajes() {
		return mensajes;
	}

	public void setMensajes(String mensajes) {
		this.mensajes.setText(mensajes);
	}

	public JTextField getRangoIni() {
		return rangoIni;
	}

	public void setRangoIni(String rangoIni) {
		this.rangoIni.setText(rangoIni);
	}

	public JTextField getRangoFin() {
		return rangoFin;
	}

	public void setRangoFin(String rangoFin) {
		this.rangoFin.setText(rangoFin);
	}

	public JTextField getmSecs() {
		return mSecs;
	}

	public void setmSecs(String mSecs) {
		this.mSecs.setText(mSecs);
	}
}
