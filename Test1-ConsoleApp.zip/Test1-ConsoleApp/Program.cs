﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace Test1_ConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {

            string test1 = "Hólà Mûndo!";//"Hola Mundo!";
                string test2 = B64EncodeUTF8(test1);
                Console.WriteLine("\nUTF8 Encoded: " + test2);
                string test3 = B64DecodeUTF8(test2);
                Console.WriteLine("\nUTF8 Decoded: " + test3);
                do { } while (Console.ReadKey(true).Key != ConsoleKey.Spacebar);
            /*string test4 = B64EncodeASCII(test1);
            Console.WriteLine("\nASCII Encoded: " + test2);
            string test5 = B64DecodeASCII(test2);
            Console.WriteLine("\nASCII Encoded: " + test3);
            do { } while (Console.ReadKey(true).Key != ConsoleKey.Spacebar);
            string test6 = B64EncodeUNI(test1);
            Console.WriteLine("\nUNICODE Encoded: " + test2);
            string test7 = B64DecodeUNI(test2);
            Console.WriteLine("\nUNICODE Encoded: " + test3);
            do { } while (Console.ReadKey(true).Key != ConsoleKey.Spacebar);
            string test8 = B64EncodeUTF7(test1);
            Console.WriteLine("\nUTF7 Encoded: " + test2);
            string test9 = B64DecodeUTF7(test2);
            Console.WriteLine("\nUTF7 Encoded: " + test3);
            do { } while (Console.ReadKey(true).Key != ConsoleKey.Spacebar);
            string test10 = B64EncodeUTF32(test1);
            Console.WriteLine("\nUTF32 Encoded: " + test2);
            string test11 = B64DecodeUTF32(test2);
            Console.WriteLine("\nUTF32 Encoded: " + test3);*/

            //using (SHA512Cng sha512Hash = /*new SHA512Managed())*/new SHA512Cng())
            using (SHA256Cng sha512Hash = /*new SHA512Managed())*/new SHA256Cng())
            {
                byte[] bytes = sha512Hash.ComputeHash(Encoding.UTF8.GetBytes(test2));
                Console.WriteLine(Encoding.UTF8.GetString(bytes));
                StringBuilder builder = new StringBuilder(128);
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("X2"));
                }
                Console.WriteLine("\nHash:\n" + builder.ToString());
                Console.WriteLine("\nB64:\n" + B64EncodeUTF8(builder.ToString()));
                Console.WriteLine("\nASCII:\n" + B64EncodeASCII(builder.ToString()));
            }
            Console.ReadKey();
        }

        private static string B64EncodeUTF8(string toEncode)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(toEncode);
            return Convert.ToBase64String(bytes);
        }
        private static string B64DecodeUTF8(string toDecode)
        {
            byte[] bytes = Convert.FromBase64String(toDecode);
            return Encoding.UTF8.GetString(bytes);
        }
        private static string B64EncodeASCII(string toEncode)
        {
            byte[] bytes = Encoding.ASCII.GetBytes(toEncode);
            return Convert.ToBase64String(bytes);
        }
        private static string B64DecodeASCII(string toDecode)
        {
            byte[] bytes = Convert.FromBase64String(toDecode);
            return Encoding.ASCII.GetString(bytes);
        }
        private static string B64EncodeUNI(string toEncode)
        {
            byte[] bytes = Encoding.Unicode.GetBytes(toEncode);
            return Convert.ToBase64String(bytes);
        }
        private static string B64DecodeUNI(string toDecode)
        {
            byte[] bytes = Convert.FromBase64String(toDecode);
            return Encoding.Unicode.GetString(bytes);
        }
        private static string B64EncodeUTF7(string toEncode)
        {
            byte[] bytes = Encoding.UTF7.GetBytes(toEncode);
            return Convert.ToBase64String(bytes);
        }
        private static string B64DecodeUTF7(string toDecode)
        {
            byte[] bytes = Convert.FromBase64String(toDecode);
            return Encoding.UTF7.GetString(bytes);
        }
        private static string B64EncodeUTF32(string toEncode)
        {
            byte[] bytes = Encoding.UTF32.GetBytes(toEncode);
            return Convert.ToBase64String(bytes);
        }
        private static string B64DecodeUTF32(string toDecode)
        {
            byte[] bytes = Convert.FromBase64String(toDecode);
            return Encoding.UTF32.GetString(bytes);
        }
    }
}
