package BackEnd;

import java.util.*;

public class Data { //TODO recuperar data de los arrays
	private ArrayList<String> aviableIPs;
	private ArrayList<String> noAviableIPs;
	
	public Data() {
		aviableIPs = new ArrayList<String>();
		noAviableIPs = new ArrayList<String>();
	}
	public boolean addAviableIP (String ip) {
		if(aviableIPs.add(ip)==true) {
			return true;
		} else {
			return false;
		}
	}
	public boolean addNoAviableIPs (String ip) {
		if(noAviableIPs.add(ip)==true) {
			return true;
		} else {
			return false;
		}
	}
	public String getAviableIP(int index) {
		if(aviableIPs.get(index).isEmpty()){
			return "nothing";
		} else {
			return aviableIPs.get(index);
		}
	}
	public String getNoAviableIP(int index) {
		if(noAviableIPs.get(index).isEmpty()){
			return "nothing";
		} else {
			return noAviableIPs.get(index);
		}
	}
}
