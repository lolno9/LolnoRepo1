﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using TestLibrary1;

namespace AMAppTest // Note: actual namespace depends on the project name.
{
    internal class Program
    {

        static void Main(string[] args)
        {
            string prueba = "Hello World!" + "\n" + "ASCII B64:\t" + Library1.B64Encode(Library1.ASCIIStringToBytes("Hello World!"));
            Console.WriteLine(prueba);
            Logs test1 = new Logs("md1.txt", prueba);
            Console.WriteLine(test1.Message("Message From Logs Library", prueba ));
            test1.Trace("prueba1 Trace", prueba, Directory.GetCurrentDirectory());
            //Console.WriteLine("Hello World!");
            //Console.WriteLine(Library1.B64Encode(Library1.ASCIIStringToBytes("Hello World!")));
            /* try
             {
                 if (!File.Exists("test.txt"))
                 {
                     File.Create("test.txt");
                     Console.WriteLine("False");
                 } else
                 {
                     File.WriteAllText("test.txt", prueba);
                     Console.WriteLine("True");
                 }

             } catch (Exception ex)
             {
                 Console.WriteLine(ex.Message);
             }
             */
            //Console.WriteLine(Directory.GetCurrentDirectory());
            Library1.Pause();
        }
    }
}